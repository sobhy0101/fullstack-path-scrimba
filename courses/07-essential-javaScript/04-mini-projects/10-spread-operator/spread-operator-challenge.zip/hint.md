To find the lowest and highest you can use Math.min and Math.max. 

You have to pass in numbers to each of those methods, but they need to be 
individual numbers, not an array of numbers. 

Think how you can expand an array of numbers into its individual variables!