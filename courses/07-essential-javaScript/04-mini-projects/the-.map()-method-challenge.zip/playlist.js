export const playlistArr = [
    {
        title: 'Bohemian Rhapsody',
        artist: 'Queen',
        albumArt: 'bohemian-rhapsody.png'
    },
    {
        title: 'As It Was',
        artist: 'Harry Styles',
        albumArt: 'as-it-was.png'
    },
    {
        title: 'Stairway to Heaven',
        artist: 'Led Zeppelin',
        albumArt: 'stairway-to-heaven.png'
    },
    {
        title: 'Therefore I Am',
        artist: 'Billie Eilish',
        albumArt: 'therefore-i-am.png'
    }
]