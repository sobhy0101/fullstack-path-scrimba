import { interplanetaryDestinationsArr as destinations, shortSpaceTripsArr } from '/data.js'

console.log(shortSpaceTripsArr)