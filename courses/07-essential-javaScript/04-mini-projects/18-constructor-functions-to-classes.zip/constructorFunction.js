function Gamer(name, score){
    this.name = name
    this.score = score
    this.incrementScore = function(){
        this.score++  
    }
}