const dateSnapshot = new Date()
console.log(`Copyright ${dateSnapshot.toString()}`)


/*
Challenge:
1. Search online to find out how we can get just the year 
   using the Date() constructor and update the console.log above.
*/
