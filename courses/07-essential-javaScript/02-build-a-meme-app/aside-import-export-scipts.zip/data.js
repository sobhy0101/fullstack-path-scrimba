export const dinnerPartyGuests = [
    'Elvis Presley', 
    'The Queen of England',
    'Alan Turing', 
    'Nelson Mandela', 
    'Mahatma Gandhi', 
    'Aristotle',
    'Albert Einstein'
    ]