import { dinnerPartyGuests } from '/data.js'


console.log(dinnerPartyGuests)