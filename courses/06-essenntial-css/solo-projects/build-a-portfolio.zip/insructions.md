1. Add the image after the <h1>
2. Center the text for the entire page
3. Add a new div with a class, wrapping all the content on the page, and assign it a width of 570px
4. Center that div on the page
